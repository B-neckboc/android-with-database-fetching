package com.example.technofarm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {
    private EditText user;
    private TextView welcomeMes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        setUpUIViews();

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");


        String message  = username + "Welcome to the App";
        welcomeMes.setText(message);
        user.setText(username);

    }

    private void setUpUIViews(){
        user = findViewById(R.id.txtUserDashboard);
        welcomeMes = findViewById(R.id.tvWelcome);


    }


}
