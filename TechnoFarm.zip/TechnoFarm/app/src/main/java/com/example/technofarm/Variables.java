package com.example.technofarm;

public class Variables {
    private String pinlevels;
    private String pinreadings;

    public String getPinlevels() {
        return pinlevels;
    }

    public void setPinlevels(String pinlevels) {
        this.pinlevels = pinlevels;
    }

    public String getPinreadings() {
        return pinreadings;
    }

    public void setPinreadings(String pinreadings) {
        this.pinreadings = pinreadings;
    }

    public Variables(String pinlevels, String pinreadings) {
        this.pinlevels = pinlevels;
        this.pinreadings = pinreadings;
    }
}
